<?php

ob_start();
drupalize();

function drupalize() {
  // stat gets statistics from the indicated file. 
  // Return false if doesnt exist. 
  while (!@stat('./includes/bootstrap.inc')) { 
  //while not exist, change to the father directory
  chdir ('..');  
  }
  define('DRUPAL_ROOT', getcwd());

  require_once DRUPAL_ROOT . './includes/bootstrap.inc';
  // Include and evaluate the indicated file it it is not included yet
  //require_once './includes/bootstrap.inc';
  drupal_bootstrap(DRUPAL_BOOTSTRAP_FULL);
}

// Crucial - to suppress Devel (if installed and enabled) output appearing in the generated XML!
$GLOBALS['devel_shutdown'] = FALSE; 
// Get proper module path.
$hgmodulepath = url( drupal_get_path('module', 'graphs/cccgraph'), array('absolute' => TRUE));
// url() ads i18n codes to the URL ... we need to remove them here...
if ( $langcode <> '' ) {  
  $hgmodulepath = str_replace( '/' . $langcode . '/', '/', $hgmodulepath );
}
// Non-clean URLs need removing ?q=
$hgmodulepath = str_replace( "?q=", "",  $hgmodulepath );
// Just supply the dtd.
if ( $_GET['dtd'] == 1 ) { 
  include $hgmodulepath . 'GraphXML.dtd'; 
  exit();
}
header("Content-type: text/xml");
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
// Cache expiration time
$hgcachexpire = 3600; 
//global $user;
$userId = $user->uid;
$hgmenucacheid = 'hg_menu_' . $userId . '_' . $_GET['par'];
ob_get_clean(); 

/**
 * ***********************************
********** XML CONSTRUCTION **********
*
*/ 
$begxml = '<?xml version="1.0"?><!DOCTYPE GraphXML SYSTEM "' . $hgmodulepath . 'hg.php?dtd=1">';
$begxml .= '<GraphXML>';
$begxml .= '<graph id="Quidne">';
$endxml = '</graph></GraphXML>';

if ( variable_get('cccgraph_cache', 'd') == 'f' ) {
  $temp = filecaching_wrapper_hgm(TRUE);
} 
else {
  $temp = caching_wrapper_hgm(TRUE); 
}

if ( $temp <> '' ) {
  echo $temp; 
} 
// Graph by default
else { 
  echo $begxml;
  echo '<node name="1"><label>just</label></node>
  <node name="2"><label>a</label></node>
  <node name="3"><label>silly</label></node>
  <node name="4"><label>demo</label></node>
  <edge source="1" target="2" />
  <edge source="1" target="3" />
  <edge source="1" target="4" />
  <edge source="4" target="3" />
  <edge source="4" target="2" />';
  echo $endxml;
}
// IMPORTANT - otherwise any process after CCC-Graph adds strings and breaks the XML!
exit(); 

/**
 * ***********************************
********** Other functions **********
*
*/ 
function filecaching_wrapper_hgm($reset = FALSE) {
  global $hgcachexpire;
  global $hgmenucacheid;
  global $begxml;
  global $endxml;

  // Determine the default temporary directory. api drupal.
  $cachedfile = file_directory_temp() . '/' . $hgmenucacheid;  
  $lastchanged = filectime( $cachedfile ); 
  if ($lastchanged === false or (time() - $lastchanged > ($hgcachexpire))) {
    // Cache file does not exist or is too old.
    $my_data = $begxml . cccgraph_get_menu($_GET['ctr']) . $endxml;
    // Now put $my_data to cache!
    $fh = fopen( $cachedfile, "w+");
  } 
  else {
    // Cache file exists.
    $my_data = file_get_contents($cachedfile);
  }
   return $my_data;
}

function caching_wrapper_hgm($reset = FALSE) {
  global $hgcachexpire;
  global $hgmenucacheid;
  global $begxml;
  global $endxml;

  static $my_data;
  // cache_get: Return data from the persistent cache. api drupal.
  if (!isset($my_data) || $reset) { 
    if (!$reset && ($cache = cache_get($hgmenucacheid)) && !empty($cache->data)) {
      $my_data = $cache->data;
    } 
    else {
      $my_data = $begxml . cccgraph_get_menu($_GET['ctr']) . $endxml;
      cache_set($hgmenucacheid,  $my_data,'cache', time() + $hgcachexpire);
    }
  }
  return $my_data;
}

function array_searchRecursive($needle, $haystack, $strict=false, $path=array()) {
  // http://be2.php.net/manual/en/function.array-search.php
  // Searches haystack for needle and returns an array of the key path if it is found in the (multidimensional) array, FALSE otherwise.
  // mixed array_searchRecursive ( mixed needle, array haystack [, bool strict[, array path]] )
  if (!is_array($haystack)) {
    return false;
  }
  foreach($haystack as $key => $val) {
    if (is_array($val) && $subPath = array_searchRecursive($needle, $val, $strict, $path)) {
      $path = array_merge($path, array($key), $subPath);
      return $path;
    } 
		elseif ((!$strict && $val == $needle) || ($strict && $val === $needle)) {
      $path[] = $key;
      return $path;
    }
  }
  return false;
}

function findepth($needle, $haystack) {
  $foundepth = 0;
  $foundparent = NULL;
  $searchparent = false;
  do {
    $searchparent = array_searchRecursive($needle, $haystack);
    if ($searchparent !== false) {
      $foundepth ++;
      unset($tempar[$searchparent]);
      $needle = $searchparent[0];
    }
  } while ($searchparent !== false);
  return $foundepth;
}

function my_in_array($needle, $haystack, $pos) {

  for ($i=$pos; $i<count($haystack); $i++) {
    if ($haystack[$i]==$needle) {
      return true;
	  }
  }
  return false;
}
 
/**
* Create the body of graph   
*
*/  
function cccgraph_get_menu($beginfrom) {
  ob_start();
    
  // Establish the root node from parameter received
  $visited = array();
  $no_visited = array();
  if ($beginfrom != '') {
    $no_visited[0] = $beginfrom;
	}
  $pp=0;
  $pr=0; 
  $level=0;
  $next_level=1;
  $setting_levels = $_GET['lev'];
  
  $fields = variable_get('cccgraph_visible_nodereferences', "");
  if($fields == "") {
    $list_fields = array();
  }
  else {
    $list_fields = explode("||", $fields);
  }

  while ($level< $setting_levels && count($visited)!=count($no_visited)) {
    // Establish relations which belongs to node_reference
    foreach($list_fields as $val) {
	    $field =  explode(";", $val);
	    $f = $field[1].'_nid';
	    // As source
	    $result = db_query("SELECT F.entity_id, F." . $f . ", F.entity_type, F.bundle, FCI.field_name FROM field_data_" . $field[1] . " F, field_config_instance FCI  WHERE F.entity_id =" . $no_visited[$pp] . " and FCI.field_name = '" . $field[1] . "'");
	    while ($row = $result->fetchObject()) {
	      if ($row->$f != "") {
	        if (!in_array ($row->$f, $visited)) {
		        $info = field_info_instance($row->entity_type, $row->field_name, $row->bundle);
	          $label = $info['label'];
	          $relations[$pr]["nid"]= $row->entity_id;
	          $relations[$pr]["target"]= $row->$f;
	          $relations[$pr]["name"]=  t($label);
	          $relations[$pr]["type"]=  "node_reference";
	          $relations[$pr]["color"]=  $field[3];
	          $pr++;
	
	          if (!my_in_array($row->$f, $no_visited, $pp)) {
	            $no_visited[count($no_visited)]=$row->$f;
	          }
	        }
	      }
	    }
	    // As target
	    $result = db_query("SELECT F.entity_id, F." . $f . ", F.entity_type, F.bundle, FCI.field_name FROM field_data_" . $field[1] . " F, field_config_instance FCI  WHERE F." . $field[1] . "_nid =" . $no_visited[$pp] . " and FCI.field_name = '" . $field[1] . "'");
	    while ($row = $result->fetchObject()) {
	      if (!in_array ($row->entity_id, $visited)) {
	        $info = field_info_instance($row->entity_type, $row->field_name, $row->bundle);
	        $label = $info['label'];
	        $relations[$pr]["nid"]= $row->entity_id;
	        $relations[$pr]["target"]= $row->$f;
	        $relations[$pr]["name"]= t($label);
	        $relations[$pr]["type"]=  "node_reference";
	        $relations[$pr]["color"]=  $field[3];
	        $pr++;
	        if (!my_in_array($row->entity_id, $no_visited, $pp) ) {
	          $no_visited[count($no_visited)]=$row->entity_id;
	        }
	      }
	    } 
    }
		// Establish relations which belongs to taxonomy
    $fields_tax = variable_get('cccgraph_visible_taxonomies', "");
    if ($fields_tax == "") {
      $list_fields_tax = array();
    }
    else {
      $list_fields_tax = explode("||", $fields_tax);
    }
    $terms = array();
    foreach($list_fields_tax as $val) {
      $field =  explode(";", $val);
      $f = $field[1].'_tid';

      $result = db_query("SELECT " . $f . " FROM field_data_" . $field[1] . " WHERE entity_id =" . $no_visited[$pp]);
      while ($row = $result->fetchObject()) {

        if ($row->$f != "" && !in_array($row->f, $terms)) {
          $terms[]=$row->$f;
        }
      }
    }
    foreach($list_fields_tax as $val) {
      $field =  explode(";", $val);
      $f = $field[1].'_tid';

      $result = db_query("SELECT fd.* , td.name FROM field_data_" . $field[1] . " fd JOIN taxonomy_term_data td ON fd." . $f . " = td.tid WHERE fd.entity_id <> " . $no_visited[$pp]);
      while ($row = $result->fetchObject()) {
        if (in_array($row->$f, $terms)) { 
          if (!in_array($row->entity_id, $visited)) {
            $relations[$pr]["nid"] = $no_visited[$pp];
            $relations[$pr]["target"] = $row->entity_id;
            $relations[$pr]["name"] = $row->name;
            $relations[$pr]["type"]=  "taxonomy";
            $relations[$pr]["color"]=  $field[3];
            $pr++;
            if (!my_in_array($row->entity_id, $no_visited, $pp)) {
              $no_visited[count($no_visited)]=$row->entity_id;
            }
          }
        }
      }
    }
    $visited[count($visited)]=$no_visited[$pp];
    $pp++;  
    if ($next_level==$pp) {
      $next_level=count($no_visited);
      $level++;
    }
  }
  $fields = variable_get('cccgraph_nodes_color', "");
  $nodes_color = explode("||", $fields);
    
  // Extract nodes
  $result = db_query("SELECT nid, title, type FROM node");
  while ($row2 = $result->fetchObject()) {
    if (in_array($row2->nid, $no_visited)) {
      echo "<node class='" . $row2->type . "' name='" . $row2->nid . "'><label>" . $row2->title . "</label>";
      if ($row2->nid == $beginfrom) {
        $center_color =  $_GET['ctrclr'];
        $center_color_text =  $_GET['ctrclrtxt'];
        echo '<style><fill colour="'.$center_color.'"/></style>';
        echo '<style><line colour="'.$center_color_text.'"/></style>';
      }
      else {
        $cn = 'Navy';
        foreach($nodes_color as $field) {
          $f1=explode(";", $field);
          if ($f1[0] == $row2->type) {
            $cn = $f1[1];
          }
        }
        echo '<style><fill colour="'.$cn.'"/></style>';
      }
      echo '<dataref><ref xlink:show="replace" xlink:href="node/' . $row2->nid . '" /></dataref>';
      echo '</node>';
    }
  }
	// Extract relations
  for ($i=0; $i<count($relations); $i++) {
    if ($relations[$i]["type"]=="node_reference") {
      $directed = 'true';
    }
    else {
      $directed = 'false';
    }
    echo '<edge class="'. $relations[$i]["name"] .'" source="'. $relations[$i]["nid"] . '" target="' . $relations[$i]["target"] . '" isDirected="'.$directed.'">';
    echo '<label>'. $relations[$i]["name"] .'</label>';
    echo '<dataref><ref xlink:show="replace" xlink:href="?q=node/' . $relations[$i]["nid"] . '" /></dataref>';
    echo '<style> <line linewidth="1" colour="' . $color = $relations[$i]["color"] . '"/> </style>';
    echo '</edge>';
  }
  // Gets the current buffer contents and delete current output buffer.  
  $temp = ob_get_clean(); 
  return $temp;
}

function microtime_float() {
  list($usec, $sec) = explode(" ", microtime());
  return ((float)$usec + (float)$sec);
}

?>
